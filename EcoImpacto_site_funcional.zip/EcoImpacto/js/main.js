
/* EcoImpacto - interações acessíveis e demonstrativas */
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.querySelector('.sr-only').textContent = open ? 'Fechar menu' : 'Abrir menu';
    });
  }

  // Preferência de tamanho de texto: salva localmente no navegador.
  const root = document.documentElement;
  const savedSize = Number(localStorage.getItem('ecoimpacto-font-size'));
  if (savedSize >= 14 && savedSize <= 22) root.style.setProperty('--base', `${savedSize}px`);
  const changeSize = (delta) => {
    const current = parseInt(getComputedStyle(root).getPropertyValue('--base')) || 16;
    const next = Math.min(22, Math.max(14, current + delta));
    root.style.setProperty('--base', `${next}px`);
    localStorage.setItem('ecoimpacto-font-size', String(next));
    const status = document.getElementById('access-status');
    if (status) status.textContent = `Tamanho do texto ajustado para ${next}px.`;
  };
  document.getElementById('font-plus')?.addEventListener('click', () => changeSize(1));
  document.getElementById('font-minus')?.addEventListener('click', () => changeSize(-1));
  document.getElementById('font-reset')?.addEventListener('click', () => {
    root.style.setProperty('--base', '16px');
    localStorage.setItem('ecoimpacto-font-size', '16');
    const status = document.getElementById('access-status');
    if (status) status.textContent = 'Tamanho do texto restaurado.';
  });

  // Formulário demonstrativo: validação no navegador, sem envio de dados.
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const status = document.getElementById('form-status');
      status.className = 'form-status';
      if (!form.checkValidity()) {
        form.classList.add('was-validated');
        status.textContent = 'Confira os campos destacados. Preencha todos os dados corretamente.';
        status.classList.add('error');
        form.reportValidity();
        return;
      }
      status.textContent = 'Tudo certo! Esta é uma demonstração: sua mensagem não foi enviada nem armazenada.';
      status.classList.add('success');
      form.reset();
      form.classList.remove('was-validated');
    });
  }
});
