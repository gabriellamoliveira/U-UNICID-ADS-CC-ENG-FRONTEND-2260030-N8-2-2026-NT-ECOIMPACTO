# EcoImpacto

**Pequenas atitudes. Grandes impactos.**

Site acadêmico da disciplina de Front-End — UNICID, 2026.

## Como executar
1. Extraia a pasta do projeto.
2. Abra `index.html` no navegador; ou execute `npm start` com Node.js instalado e acesse `http://localhost:3000`.
3. A página inicial `index.html` fica na raiz do repositório.

## Páginas
1. `index.html` — Início
2. `sobre.html` — Sobre
3. `projetos.html` — Projetos
4. `impacto.html` — Impacto
5. `acessibilidade.html` — Acessibilidade
6. `galeria.html` — Galeria
7. `midia.html` — Mídia
8. `noticias.html` — Notícias
9. `contato.html` — Contato
10. `orcamento_hospedagem.html` — Orçamento de hospedagem e domínio

## Recursos
- HTML semântico e navegação compartilhada nas dez páginas.
- CSS responsivo com Grid/Flexbox e identidade visual consistente.
- Menu móvel, link para pular ao conteúdo e foco de teclado visível.
- Formulário demonstrativo com validação JavaScript.
- Preferência de tamanho de texto salva em `localStorage`.
- Página de acessibilidade, galeria, multimídia, notícias, projetos e orçamento.
- Servidor Node simples e configuração inicial para deploy na Railway.

## Atenção
Os formulários são demonstrativos: não enviam nem armazenam dados em servidor. Os indicadores e projetos são exemplos fictícios, conforme o escopo. A área de áudio aguarda o arquivo `assets/audio-sustentabilidade.mp3`; substitua o iframe de vídeo pelo ID do vídeo educativo escolhido pela equipe. O site ainda precisa ser enviado ao GitHub e publicado em um serviço de hospedagem; a criação destes arquivos não realiza o deploy.

## Publicação
- GitHub: crie um repositório e envie o conteúdo desta pasta. Mantenha `index.html` na raiz.
- Railway: conecte o repositório GitHub; o projeto usa `npm start` para iniciar `server.js`.
- Domínio: configure um domínio próprio no painel do provedor, se a equipe decidir contratar um.

## Equipe
Breno Santos, Diego Veiga, Felipe Tatsuo, Gabriella Oliveira, Giovanna Nascimento, Nikollas Paiva e Rafaella Oliveira.
